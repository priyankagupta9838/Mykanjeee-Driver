


class RoutesName{

  static const String  splashScreen="splashScreen_Screen";
  static const String  login="login_Screen";
  static const String  loginWithOtp="loginWithOtp_Screen";
  static const String  loginWithOtpVerification="loginWithOtpVerification_Screen";
  static const String  signUp1="signUp_Screen";
  static const String  signUp2="signUp2_Screen";
  static const String  signUpOtp="signUpOtp_Screen";
  static const String  forgotPassword="resetPasswordWithEmail_Screen";
  static const String  forgotPasswordOtp="resetPasswordWithEmailOtpVerificationl_Screen";
  static const String  forgotPasswordOtpVerification="forgotPassword_Screen";
  static const String  resetOtpVerification="resetOtpVerification_Screen";
  static const String  storageStream="storageStream_Screen";
  static const String  navigationBar="navigationBar_Screen";
  static const String  userProfile="userProfile_Screen";
  static const String  updateUserProfile="updateUserProfile_Screen";
  static const String  accountSetting="accountSetting_Screen";
  static const String  setupProfile="setupProfile_Screen";
  static const String  documentVerification="documentVerification_Screen";
  static const String  detailSaved="detailSaved_Screen";
  static const String  setUpAccountDetail="setUpAccountDetail_Screen";
  static const String  acceptedOrderDetail="orderDetail_Screen";
  static const String  assignedServiceOrderDetail="assignedServiceOrderDetail_Screen";
  static const String  assignedOrderDetail="assignedOrderDetail_Screen";
  static const String  rejectedOderDetail="rejectedOderDetail_Screen";
  static const String  deliveredOderDetail="deliveredOderDetail_Screen";
  static const String  acceptedServiceOderDetail="acceptedServiceOderDetail_Screen";
  static const String  deliveredServiceOderDetail="deliveredServiceOderDetail_Screen";
  static const String  rejectedServiceOderDetail="rejectedServiceOderDetail_Screen";
  static const String  pickUpOderDetail="pickUpOderDetail_Screen";
  static const String  dropOffOderDetail="dropOffOderDetail_Screen";




}
