import 'dart:ui';

class ThemColors{

  static const buttonColor=Color.fromRGBO(174, 144, 194, 1);


}